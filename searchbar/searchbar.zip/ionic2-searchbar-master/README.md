# ionic2-searchbar
Searchbar tutorial for Ionic 2
